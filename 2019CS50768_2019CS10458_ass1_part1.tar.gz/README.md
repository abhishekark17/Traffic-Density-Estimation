Extract the tar file using `tar -xvf 2019CS50768_2019CS10458_ass1_part1.tar.gz`.<br />
The file will be extracted in the same folder so no need to change the directory.<br />
For compilation use `make all` or simply `make`.<br />
The name of the executable file is **main**.<br />
For running the file you must provide the name of the image as argument.<br />
For example if my file name is **empty.jpg** then you should type `./main empty.jpg`.<br />
